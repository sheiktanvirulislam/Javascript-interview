let name ;
function add(num1,num2){
   console.log(num1 + num2);
return 
}


function add(num1,num2) {
    console.log(num2);
}
const result = add(12)
const person = {name:"rohan",phone:907465}; 
console.log(person.address); 
let fun = undefined;
console.log(fun);
let number1 = 12;








function palindrome(word) {
    // let word1 = word + '';
    let word2 = word.split('').reverse().join('');
    if (word2 == word) {
        return true;
    }
    else {
        return false;
    }
}
console.log(palindrome(''))