// 0 , "",undefined,null , false these are falsy value
//truth- "0",' ',

// const name1 = "tanvir";
let name1 = 'false';
console.log(name1)
if (name1) {
    console.log("true")
}
else {
    console.log("false")
}







// if (name1>=18) {
//     console.log("you can vote")
// }
// else {
//     console.log("you can't vote")
// }